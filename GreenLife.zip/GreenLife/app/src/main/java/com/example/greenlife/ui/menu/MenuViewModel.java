package com.example.greenlife.ui.menu;

import android.app.Application;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.example.greenlife.App;
import com.example.greenlife.db.AppDatabase;
import com.example.greenlife.db.dao.MenuInfoDao;
import com.example.greenlife.db.entity.MenuInfo;
import com.example.greenlife.model.MenuModel;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Observer;


public class MenuViewModel extends AndroidViewModel{

    private MenuModel model;

    public MenuViewModel(Application application){
        super(application);
        model = new MenuModel();
        AppDatabase db = ((App) application).getDatabase();
        MenuInfoDao menuInfoDao = db.menuInfoDao();

        new Thread(new Runnable() {
            @Override
            public void run() {
                menuInfoDao.insert(new MenuInfo("00.00.00"));
            }
        }).start();

    }

    public void updateMenuInfoDao(){
        Date currentDate = new Date();
        // Форматирование времени как "день.месяц.год"
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
        String dateText = dateFormat.format(currentDate);

        menuInfoDao.update(new MenuInfo(dateText));
    }

//    public void getMenuInfoDao(){
//        menuInfoDao.getById(2);
//    }

    public LiveData<String> getDayLiveData(){
        return model.getDayLiveData();
    }

    public void time(){
        model.time(menuInfoDao.getById(0).day);
    }

}

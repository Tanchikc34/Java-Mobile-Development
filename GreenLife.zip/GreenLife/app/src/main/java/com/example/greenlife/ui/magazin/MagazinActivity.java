package com.example.greenlife.ui.magazin;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.greenlife.R;

import java.util.ArrayList;

public class MagazinActivity  extends AppCompatActivity {

    ArrayList<State> states = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.magazin_layout);
        // начальная инициализация списка
        setInitialData();
        RecyclerView recyclerView = findViewById(R.id.list);
        // создаем адаптер
        StateAdapter adapter = new StateAdapter(this, states);
        // устанавливаем для списка адаптер
        recyclerView.setAdapter(adapter);
    }
    private void setInitialData(){

        states.add(new State ("Цвет горшка \"Лето\" (красный, бежевый, оранжевый)", R.drawable.plant_color1));
        states.add(new State ("Цвет горшка \"Море\" (голубой, тёмно-синий)", R.drawable.plant_color2));
        states.add(new State ("Цвет горшка \"Пляж\" (бордовый, оранжевый)", R.drawable.plant_color3));
        states.add(new State ("Цвет горшка \"Морской\"", R.drawable.plant_color4));
        states.add(new State ("Цвет горшка \"Фиолетовый\"", R.drawable.plant_color5));
    }
}

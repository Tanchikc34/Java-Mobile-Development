package com.example.greenlife.model;

import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class MenuModel {

    private String day;

    private MutableLiveData<String> dayData;

    public MenuModel(){
        day = "0";
        dayData = new MutableLiveData<>(day);
    }

    public LiveData<String> getDayLiveData() {
        return dayData;
    }

    public void time(String time){
        // Текущее время
        Date currentDate = new Date();
        // Форматирование времени как "день.месяц.год"
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
        String dateText = dateFormat.format(currentDate);

        Date startDate = null;

        try {
            startDate = new SimpleDateFormat("dd.MM.yyyy").parse(dateText);
        } catch (ParseException exc) {
            exc.printStackTrace();
        }

        Date endDate = null;
        try {
            endDate = new SimpleDateFormat("dd.MM.yyyy").parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
        }


        Calendar calendarStart = Calendar.getInstance();
        calendarStart.setTimeInMillis(startDate.getTime());

        Calendar calendarEnd = Calendar.getInstance();
        calendarEnd.setTimeInMillis(endDate.getTime());

        long difference = calendarEnd.getTimeInMillis() - calendarStart.getTimeInMillis();
        long days = difference /(24* 60 * 60 * 1000);
        String a = String.valueOf(days);
        dayData.postValue(a);
    }

}
